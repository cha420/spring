package com.capg.SPringBootDemo1.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.SPringBootDemo1.DAO.EmployeeDAO;
import com.capg.SPringBootDemo1.DAO.EmployeeRepository;
import com.capg.SPringBootDemo1.model.Employee;

@Service
@Transactional
public class EmployeeService {
	
	private EmployeeRepository er;
	
	@Autowired
	public EmployeeService(EmployeeRepository er) {
		super();
		this.er = er;
	}

//	private EmployeeDAO employeedao;
//	
//	@Autowired
//	public EmployeeService(EmployeeDAO employeedao) {
//		super();
//		this.employeedao = employeedao;
//	}



	public List<Employee> getSortedEmpList(){
//		List<Employee>empList = employeedao.findAll();
		List<Employee>empList=er.findAll();
		return empList;
		
	}
	
	public Employee saveNewEmployee(Employee emp) {
		return er.save(emp);
	}
	
	
	public boolean removeEmployee(int empId) {
		try {
		er.deleteById(empId);
		return true;
		}catch(IllegalArgumentException e) {
			return false;
			
		}
	}
	
	public Employee getEmp(int empId) {
		Optional<Employee>emp=er.findById(empId);
		return emp.get();
//		return employeedao.find(empId);
	}
}
