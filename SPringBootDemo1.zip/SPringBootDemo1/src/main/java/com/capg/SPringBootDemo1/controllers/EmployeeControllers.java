package com.capg.SPringBootDemo1.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;


import com.capg.SPringBootDemo1.model.Employee;
import com.capg.SPringBootDemo1.services.EmployeeService;

@RestController
public class EmployeeControllers {
	
	private EmployeeService empservice;
	
	
	@Autowired
	public EmployeeControllers(EmployeeService empservice) {
		super();
		this.empservice = empservice;
	}

	 @CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value="/employees")
	public List<Employee> getEmp() {
		
		return empservice.getSortedEmpList();
	}
	
	 @CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value="/employees")
	public Employee createEmployee(@RequestBody Employee emp) {
		return empservice.saveNewEmployee(emp);
		
	}
	
	@GetMapping(value="/employees/{empId}")
	public Employee getEmployee(@PathVariable int empId) {
		return empservice.getEmp(empId);
		
	}
	 @CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/employees/{empId}")
	public Employee removeEmp(@PathVariable int empId) {
		
		Employee emp=empservice.getEmp(empId);
		if(emp!=null) {
		
		if (empservice.removeEmployee(empId)) {
			return emp;
		}
		else {
			throw new RuntimeException("Could not be find Employee");
		}
		}
		else {
			throw new RuntimeException("Could not find Employee");
		}
	}
}
