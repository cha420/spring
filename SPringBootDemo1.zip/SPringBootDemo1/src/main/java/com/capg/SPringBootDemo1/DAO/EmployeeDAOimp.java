package com.capg.SPringBootDemo1.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.SPringBootDemo1.model.Employee;


@Repository
@Transactional
public class EmployeeDAOimp implements EmployeeDAO {

	
	//entityManager
	private EntityManager em;
	
	//Constructor
	@Autowired
	public EmployeeDAOimp(EntityManager em) {
		super();
		this.em = em;
	}

	@Override
	public Employee find(int empId) {
		Employee emp = em.find(Employee.class, empId);
		return emp;
	}

	@Override
	public List<Employee> findAll() {
		TypedQuery<Employee> query=em.createQuery("SELECT e FROM Employee e", Employee.class);
		List <Employee> li = query.getResultList();
		
		return li;
	}

	@Override
	public Employee save(Employee emp) {
		em.persist(emp);
		return em.merge(emp);
	}

	@Override
	public boolean deletesById(int empId) {
		Employee emp = this.find(empId);
		if(emp!=null) {
			em.remove(emp);
			return true;
	}else {
		return false;}	}
	


	
	

}
