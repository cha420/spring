package com.capg.SPringBootDemo1;

import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SPringBootDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
