import { Component, OnInit } from '@angular/core';

import { HttpClient } from '../../../node_modules/@angular/common/http';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  private empData:any[] = [];

  constructor(private http:HttpClient) { }

  ngOnInit() {

    this.http.get<any[]>('http://localhost:8084/employees')
              .subscribe(
                (response:any[])=>{
                  console.log('response recieved from server....')
                  console.log(response)
                  this.empData=response;
                },
                (error)=>{
                  console.log('error from server...')
                  console.log(error)
                }
              )
  }
  deleteemp(emp){
    this.http.delete<any>('http://localhost:8084/employees'+'/'+emp.empId)
      .subscribe(
        (response)=>{
          const index = this.empData.indexOf(emp)
          this.empData.splice(index,1)
          console.log('delete response recieved from server....')
          
        },
        (error)=>{
          console.log('error from server...')
          console.log(error)
        }
      )

  }

}
