# Angular2 Flight Booking Online Web App

This project was generated with Angular-cli
