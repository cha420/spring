package com.capg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


import com.capg.entities.MovieCategory;

//@RestResource
@RepositoryRestResource
public interface MovieCategoryRepository extends JpaRepository<MovieCategory,Integer> {

}
