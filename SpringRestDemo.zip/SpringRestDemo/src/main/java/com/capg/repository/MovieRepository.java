package com.capg.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import com.capg.entities.Movie;


@RepositoryRestResource
public interface MovieRepository extends JpaRepository<Movie,Integer> {
	
	//custom methods

	Movie findByTitle(@Param("title") String title);
	
	List<Movie> findAllByTitle(String title);
	
	Movie findByTitleAndDescriptoin(String title,String descriptoin);
	
	List<Movie> findAllByDailyRentalRateGreaterThan(int number);
	
//	@Query("SELECT m  FROM MOVIE m WHERE m.stockInHand>0")
//	List<Movie> getAllMoviesWhoesStockIsZero();
	
}
