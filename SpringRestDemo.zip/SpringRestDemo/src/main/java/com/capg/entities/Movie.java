package com.capg.entities;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.rest.core.annotation.RestResource;

@Entity

public class Movie {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int movieId;
	private String title;
	private String descriptoin;
	private int dailyRentalRate;
	private int stockInHand;
	@OneToOne
	@RestResource(path="movieCategories",rel="mcatId")
	private MovieCategory category;
	
	public Movie() {
		super();
	}
	

	public Movie(String title, String descriptoin, int dailyRentalRate, int stockInHand, MovieCategory category) {
		super();
		this.title = title;
		this.descriptoin = descriptoin;
		this.dailyRentalRate = dailyRentalRate;
		this.stockInHand = stockInHand;
		this.category = category;
	}


	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescriptoin() {
		return descriptoin;
	}

	public void setDescriptoin(String descriptoin) {
		this.descriptoin = descriptoin;
	}

	public int getDailyRentalRate() {
		return dailyRentalRate;
	}

	public void setDailyRentalRate(int dailyRentalRate) {
		this.dailyRentalRate = dailyRentalRate;
	}

	public int getStockInHand() {
		return stockInHand;
	}

	public void setStockInHand(int stockInHand) {
		this.stockInHand = stockInHand;
	}
	
	public MovieCategory getCategory() {
		return category;
	}


	public void setCategory(MovieCategory category) {
		this.category = category;
	}


	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", title=" + title + ", descriptoin=" + descriptoin + ", dailyRentalRate="
				+ dailyRentalRate + ", stockInHand=" + stockInHand + ", category=" + category + "]";
	}


	
	
}
