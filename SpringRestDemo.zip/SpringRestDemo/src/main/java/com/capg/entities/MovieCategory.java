package com.capg.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity

public class MovieCategory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int mcatId;
	private String mcatName;
	
	@OneToMany(mappedBy="category")
	private List< Movie> movie;
	
	public MovieCategory() {
		super();
	}

	
	


	public MovieCategory(String mcatName, List<Movie> movie) {
		super();
		this.mcatName = mcatName;
		this.movie = movie;
	}





	public int getMcatId() {
		return mcatId;
	}

	public void setMcatId(int mcatId) {
		this.mcatId = mcatId;
	}

	public String getMcatName() {
		return mcatName;
	}

	public void setMcatName(String mcatName) {
		this.mcatName = mcatName;
	}
	

	


	public List<Movie> getMovie() {
		return movie;
	}





	public void setMovie(List<Movie> movie) {
		this.movie = movie;
	}





	


	
	
	

}
