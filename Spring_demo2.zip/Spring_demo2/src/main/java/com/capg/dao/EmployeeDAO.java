package com.capg.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capg.model.Employee;

@Repository
public class EmployeeDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	public Employee getEmp() {
		Employee emp = new Employee("Mayu","Chennai",30000.00);
		return null;
		
	}

}
