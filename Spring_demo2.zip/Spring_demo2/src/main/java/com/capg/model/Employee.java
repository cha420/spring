package com.capg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Employee {
	
	@Id
	@GeneratedValue()
	private int eid;
	private String ename;
	private String city;
	private double salary;
	
	public Employee() {
		super();
	}

	public Employee(String ename, String city, double salary) {
		super();
		this.ename = ename;
		this.city = city;
		this.salary = salary;
	}
	
	

	public Employee(int eid, String ename, String city, double salary) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.city = city;
		this.salary = salary;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	
	
}
