package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.capg.model.Employee;
import com.capg.services.EmployeeService;
import com.fasterxml.jackson.core.JsonProcessingException;


@Controller
public class EmployeeController {
	
	private EmployeeService empService;
	
		
	public EmployeeController() {
		super();
	}
	
	@Autowired
	public EmployeeController(EmployeeService empService) {
		super();
		this.empService = empService;
	}


	@ResponseBody
	@RequestMapping("/hello")
	public String sayHello() {
		System.out.println("Saying Hello.........");
		return "Hello from Employee Controller";
	}
	
	@RequestMapping("/getemp")
	@ResponseBody
	public String getEmp() throws JsonProcessingException  {
		Employee emp = empService.getEmp() ;
		
		return empService.convertEmpToJson(emp);
		
		
		
		
	}
}
