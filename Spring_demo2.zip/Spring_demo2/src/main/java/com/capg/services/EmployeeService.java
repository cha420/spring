package com.capg.services;

import org.springframework.stereotype.Service;

import com.capg.dao.EmployeeDAO;
import com.capg.model.Employee;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EmployeeService {
	
	private EmployeeDAO empdao;
	
	public Employee getEmp() throws JsonProcessingException  {
		
		return null;
	}
	
	public String convertEmpToJson(Employee emp) throws JsonProcessingException {
		ObjectMapper map = new ObjectMapper();
		
		String s =map.writeValueAsString(emp);
		return s;
	}

}
